'use client';
import {useEffect,useRef,useState} from 'react';
import {ArrowDown,ArrowUpRight} from 'lucide-react';
import sales from './properties.json';
import rentals from './rentals.json';

export default function PropertyGallery({motion,rental=false}:{motion:boolean,rental?:boolean}){
 const properties=rental?rentals:sales;const sectionId=rental?"locations":"nos-biens";const lead=.45;
 const section=useRef<HTMLElement>(null),track=useRef<HTMLDivElement>(null),viewport=useRef<HTMLDivElement>(null);
 const [travel,setTravel]=useState(0),[size,setSize]=useState({w:1,h:1,x:0,y:0,iw:1,ih:1});
 const [pinned,setPinned]=useState(false),[distance,setDistance]=useState(0),[progress,setProgress]=useState(0);
 useEffect(()=>{setPinned(motion)},[motion]);
 useEffect(()=>{
  if(!pinned){setDistance(0);setProgress(0);if(section.current)section.current.style.opacity='1';return;}
  let frame=0;
  const measure=()=>{if(track.current&&viewport.current)setDistance(Math.max(0,track.current.scrollWidth-viewport.current.clientWidth));};
  const update=()=>{frame=0;if(section.current){const sticky=section.current.firstElementChild as HTMLElement;const image=track.current?.querySelector('.property-image-link') as HTMLElement;const h=sticky.offsetHeight;section.current.style.opacity=String(rental?1:Math.max(0,Math.min(1,(innerHeight*.65-section.current.getBoundingClientRect().top)/(innerHeight*.4))));const y=Math.max(0,-section.current.getBoundingClientRect().top+h*lead);setTravel(y);const d=Math.max(1,section.current.offsetHeight-h-h*(2-lead));setProgress(Math.max(0,Math.min(1,(y-h*2)/d)));if(image){setSize({w:sticky.clientWidth,h,x:(track.current!.firstElementChild as HTMLElement).offsetLeft,y:viewport.current!.offsetTop,iw:image.offsetWidth,ih:image.offsetHeight});}}};
  const scroll=()=>{if(!frame)frame=requestAnimationFrame(update);};
  const observer=new ResizeObserver(()=>{measure();scroll()});
  if(track.current)observer.observe(track.current);if(viewport.current)observer.observe(viewport.current);
  measure();scroll();addEventListener('scroll',scroll,{passive:true});addEventListener('resize',scroll);
  return()=>{observer.disconnect();cancelAnimationFrame(frame);removeEventListener('scroll',scroll);removeEventListener('resize',scroll)};
 },[pinned,rental]);
 const go=(index:number)=>{
  const card=track.current?.children[index] as HTMLElement|undefined;
  if(!card||!section.current||!viewport.current)return;
  if(pinned){const start=section.current.getBoundingClientRect().top+scrollY;window.scrollTo({top:start+size.h*(2-lead)+Math.min(distance,card.offsetLeft-(track.current!.firstElementChild as HTMLElement).offsetLeft),behavior:motion?'smooth':'auto'});}
  else card.scrollIntoView({behavior:'auto',block:'center'});
 };
 const reveal=Math.min(1,travel/Math.max(1,size.h*1.3));
 const settle=Math.max(0,Math.min(1,(travel-size.h*1.3)/Math.max(1,size.h*.7)));
 const ease=settle*settle*(3-2*settle);
 const radius=Math.min(size.w*.15,size.h*.105),cx=size.w/2,cy=size.h*.53,scale=1+Math.pow(reveal,2.5)*35;
 const points=Array.from({length:61},(_,i)=>{const a=(140+i*260/60)*Math.PI/180;return `${cx+Math.cos(a)*radius*scale}px ${cy+Math.sin(a)*radius*scale}px`});
 points.push(`${cx+radius*.93*scale}px ${cy+radius*2.21*scale}px`,`${cx-radius*.93*scale}px ${cy+radius*2.21*scale}px`);
 const entering=pinned&&settle<1;
 const current=Math.round(progress*(properties.length-1));
 return <section ref={section} id={sectionId} className={`properties ${pinned?'is-pinned':''} ${rental?'rental-gallery':''}`} style={pinned?{height:`calc(${(3-lead)*100}svh + ${distance}px)`}:undefined} aria-labelledby={`${sectionId}-title`}>
  <div className="property-sticky">
   {entering&&<div className="keyhole-intro" aria-hidden="true" style={{background:reveal<1?'#102f3c':'transparent'}}>
    <div className="keyhole-photo" style={{left:size.x*ease,top:size.y*ease,width:size.w+(size.iw-size.w)*ease,height:size.h+(size.ih-size.h)*ease,clipPath:reveal<1?(rental?`inset(${Math.max(0,20-reveal*30)}% ${Math.max(0,35-reveal*53)}% ${Math.max(0,8-reveal*15)}%)`:`polygon(${points.join(',')})`):'none'}}><img src={`./${properties[0].id}.jpg`} alt=""/></div>
    {rental&&reveal<1&&<div className="rental-door-frame" style={{opacity:Math.max(0,1-reveal*1.25)}}><div className="rental-door" style={{transform:`perspective(1000px) rotateY(${-reveal*110}deg)`}}><span className="rental-door-label">BIENVENUE<br/>CHEZ VOUS</span><span className="rental-door-handle"/></div></div>}
    <div className="keyhole-copy" style={{opacity:Math.max(0,1-reveal*4)}}><p className="eyebrow">{rental?"LOUER AVEC QLEÏA":"ACHETER AVEC QLEÏA"}</p><h2>{rental?<>Une nouvelle porte.<br/>Votre nouvelle <em>adresse.</em></>:<>Votre prochain chapitre<br/>commence <em>ici.</em></>}</h2></div>
    <span className="keyhole-hint" style={{opacity:Math.max(0,1-reveal*3)}}><ArrowDown size={18}/> Faites défiler pour entrer</span>
   </div>}
   <div className="property-heading"><div><p className="eyebrow">{rental?"LES LOCATIONS QLEÏA":"LA SÉLECTION QLEÏA"} / 01—0{properties.length}</p><h2 id={`${sectionId}-title`}>{rental?<>Les clés de votre<br/>prochain <em>chez-vous.</em></>:<>Et si votre prochain<br/>chapitre était <em>ici ?</em></>}</h2></div><div className="property-intro"><p>Des lieux à découvrir.<br/>Une nouvelle histoire à écrire.</p><a href={rental?"https://www.qleia.com/location/1":"https://www.qleia.com/"}>{rental?"Toutes les locations":"Tous nos biens"} <ArrowUpRight size={18}/></a></div></div>
   <div ref={viewport} className="property-viewport" inert={entering} tabIndex={entering?-1:0} aria-label={`${properties.length} ${rental?"locations":"biens à vendre"}. Faites défiler vers le bas pour explorer.`} onKeyDown={e=>{if(pinned&&(e.key==='ArrowRight'||e.key==='ArrowLeft')){e.preventDefault();go(Math.max(0,Math.min(properties.length-1,current+(e.key==='ArrowRight'?1:-1))))}}}>
    <div ref={track} className="property-track" style={pinned?{transform:`translate3d(${-progress*distance}px,0,0)`}:undefined}>
    {properties.map((home,i)=><article className="property-card" key={home.id}>
     <a href={home.href} target="_blank" rel="noreferrer" className="property-image-link" tabIndex={entering?-1:0} onFocus={e=>{if(e.currentTarget.matches(':focus-visible'))go(i)}} aria-label={`Voir l’annonce : ${home.city}, ${home.price}`}>
      <img src={`./${home.id}.jpg`} alt={home.title+' à '+home.city} loading={i===0?"eager":"lazy"}/>
      <span className="property-tag">{rental?"À LOUER":"À VENDRE"}</span><span className="property-number">0{i+1}</span><span className="property-open"><ArrowUpRight size={24}/></span>
      <div className="property-caption"><h3>{home.city}</h3><span>{home.price}</span></div>
     </a>
     <div className="property-description"><p>{home.title}</p><span>{home.details}</span></div>
    </article>)}
    </div>
   </div>
   <div className="property-bottom"><span className="scroll-hint"><ArrowDown size={15}/>Continuez à descendre pour explorer</span><div className="property-progress" aria-hidden="true"><span style={{transform:`scaleX(${pinned?(progress*.8+.2):1})`}}/></div><div className="property-controls">{properties.map((h,i)=><button key={h.id} onClick={()=>go(i)} aria-label={`Afficher le bien à ${h.city}`} aria-current={pinned&&current===i?'true':undefined}>0{i+1}</button>)}</div></div>
   <p className="property-note">Sélection issue du site Qleïa · Prix et disponibilités à confirmer sur chaque annonce.</p>
  </div>
 </section>
}
