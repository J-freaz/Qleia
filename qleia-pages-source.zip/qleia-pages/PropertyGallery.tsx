'use client';
import {useEffect,useRef,useState} from 'react';
import {ArrowDown,ArrowUpRight} from 'lucide-react';
import properties from './properties.json';

export default function PropertyGallery({motion}:{motion:boolean}){
 const section=useRef<HTMLElement>(null),track=useRef<HTMLDivElement>(null),viewport=useRef<HTMLDivElement>(null);
 const [pinned,setPinned]=useState(false),[distance,setDistance]=useState(0),[progress,setProgress]=useState(0);
 useEffect(()=>{setPinned(motion)},[motion]);
 useEffect(()=>{
  if(!pinned){setDistance(0);setProgress(0);return;}
  let frame=0;
  const measure=()=>{if(track.current&&viewport.current)setDistance(Math.max(0,track.current.scrollWidth-viewport.current.clientWidth));};
  const update=()=>{frame=0;if(section.current){const d=Math.max(1,section.current.offsetHeight-(section.current.firstElementChild as HTMLElement).offsetHeight);setProgress(Math.max(0,Math.min(1,-section.current.getBoundingClientRect().top/d)));}};
  const scroll=()=>{if(!frame)frame=requestAnimationFrame(update);};
  const observer=new ResizeObserver(()=>{measure();scroll()});
  if(track.current)observer.observe(track.current);if(viewport.current)observer.observe(viewport.current);
  measure();scroll();addEventListener('scroll',scroll,{passive:true});addEventListener('resize',scroll);
  return()=>{observer.disconnect();cancelAnimationFrame(frame);removeEventListener('scroll',scroll);removeEventListener('resize',scroll)};
 },[pinned]);
 const go=(index:number)=>{
  const card=track.current?.children[index] as HTMLElement|undefined;
  if(!card||!section.current||!viewport.current)return;
  if(pinned){const start=section.current.getBoundingClientRect().top+scrollY;window.scrollTo({top:start+Math.min(distance,card.offsetLeft-(track.current!.firstElementChild as HTMLElement).offsetLeft),behavior:motion?'smooth':'auto'});}
  else card.scrollIntoView({behavior:'auto',block:'center'});
 };
 const current=Math.round(progress*(properties.length-1));
 return <section ref={section} id="nos-biens" className={`properties ${pinned?'is-pinned':''}`} style={pinned?{height:`calc(100svh + ${distance}px)`}:undefined} aria-labelledby="properties-title">
  <div className="property-sticky">
   <div className="property-heading"><div><p className="eyebrow">LA SÉLECTION QLEÏA / 01—03</p><h2 id="properties-title">Et si votre prochain<br/>chapitre était <em>ici ?</em></h2></div><div className="property-intro"><p>Des lieux à découvrir.<br/>Une nouvelle histoire à écrire.</p><a href="https://www.qleia.com/">Tous nos biens <ArrowUpRight size={18}/></a></div></div>
   <div ref={viewport} className="property-viewport" tabIndex={0} aria-label="Sélection de trois biens. Utilisez les flèches ou faites défiler." onKeyDown={e=>{if(pinned&&(e.key==='ArrowRight'||e.key==='ArrowLeft')){e.preventDefault();go(Math.max(0,Math.min(properties.length-1,current+(e.key==='ArrowRight'?1:-1))))}}}>
    <div ref={track} className="property-track" style={pinned?{transform:`translate3d(${-progress*distance}px,0,0)`}:undefined}>
    {properties.map((home,i)=><article className="property-card" key={home.id}>
     <a href={home.href} target="_blank" rel="noreferrer" className="property-image-link" onFocus={e=>{if(e.currentTarget.matches(':focus-visible'))go(i)}} aria-label={`Voir l’annonce : ${home.city}, ${home.price}`}>
      <img src={`./${home.id}.jpg`} alt={home.title+' à '+home.city} loading="lazy" style={pinned?{transform:`scale(${1.04+Math.min(.08,Math.abs(progress-i/2)*.08)})`}:undefined}/>
      <span className="property-tag">À DÉCOUVRIR</span><span className="property-number">0{i+1}</span><span className="property-open"><ArrowUpRight size={24}/></span>
      <div className="property-caption"><h3>{home.city}</h3><span>{home.price}</span></div>
     </a>
     <div className="property-description"><p>{home.title}</p><span>{home.details}</span></div>
    </article>)}
    </div>
   </div>
   <div className="property-bottom"><span className="scroll-hint"><ArrowDown size={15}/>Continuez à descendre pour explorer</span><div className="property-progress" aria-hidden="true"><span style={{transform:`scaleX(${pinned?(progress*.8+.2):1})`}}/></div><div className="property-controls">{properties.map((h,i)=><button key={h.id} onClick={()=>go(i)} aria-label={`Afficher le bien à ${h.city}`} aria-current={pinned&&current===i?'true':undefined}>0{i+1}</button>)}</div></div>
   <p className="property-note">Sélection issue du site Qleïa · Prix et disponibilités à confirmer sur chaque annonce.</p>
  </div>
 </section>
}
